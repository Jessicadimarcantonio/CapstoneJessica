USE [ITSalaries2023]
GO

/****** Object:  View [dbo].[JDM_vFactSalaries]    Script Date: 11/11/2023 09:47:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [dbo].[JDM_vFactSalaries] as (
SELECT s.WorkYear
,el.ExperienceName
,et.EmploymentName
,s.JobTitle
,s.Salary
,s.SalaryCurrency
,c.CurrencyName
,s.SalaryUSD
,g.Country as ConutryEmployee
,g.RegionName as RegionEmployee
,r.WorkType
,gc.Country as CountryCompany
,gc.RegionName as RegionCompany
,cd.DimName as DimensionCompany
FROM SalariesIT S
INNER JOIN ExperienceLevel EL
ON S.ExperienceLevel=EL.ExperienceID
INNER JOIN EmploymentType ET
ON S.EmploymentType=ET.EmploymentID
INNER JOIN Currency c
on s.SalaryCurrency=c.CurrencyID
INNER JOIN Geograph g
ON s.EmployeeResidence=g.ISOCodeID
INNER JOIN RemoteRatio r
ON s.RemoteRatio=r.RemoteID
INNER JOIN GeographCompany gc
ON S.CompanyLocation=gc.ISOCodeID
INNER JOIN CompanyDimension cd
ON s.CompanySize=cd.CompanyDimID
)
GO


