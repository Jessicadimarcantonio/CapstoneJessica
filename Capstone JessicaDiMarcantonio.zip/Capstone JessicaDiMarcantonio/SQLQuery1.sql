select*
from JDM_vFactSalaries

CREATE VIEW [dbo].[JDM_top10_2023] as (
select top 10 JobTitle, SalaryUSD, CountryCompany
		from JDM_vFactSalaries
		WHERE YEAR(WorkYear) = 2023
		--GROUP BY JobTitle, SalaryUSD,CountryCompany
		--HAVING SUM(SalaryUSD) > 100000
		ORDER BY SalaryUSD desc
		)



CREATE VIEW [dbo].[JDM_top10_DA] as (
select top 10 SalaryUSD, CountryCompany, JobTitle
		from JDM_vFactSalaries
		WHERE YEAR(WorkYear) = 2023 and JobTitle='Data Analyst'
		--GROUP BY JobTitle, SalaryUSD,CountryCompany
		--HAVING SUM (SalaryUSD)>1000
		ORDER BY SalaryUSD desc
		)