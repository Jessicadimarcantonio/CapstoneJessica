CREATE DATABASE ITSalaries2023;

CREATE TABLE ExperienceLevel (
ExperienceID varchar (5)
,ExperienceName varchar(30)
constraint PK_ExperienceLevel_ExperienceID primary key (ExperienceID)
)

CREATE TABLE EmploymentType (
EmploymentID varchar (5)
,EmploymentName varchar(30)
constraint PK_EmploymentType_EmploymentID primary key (EmploymentID)
)

CREATE TABLE Currency (
CurrencyID varchar (5)
,CurrencyName varchar(30)
constraint PK_Currency_CurrencyID primary key (CurrencyID)
)

CREATE TABLE Geograph (
ISOCodeID varchar (5)
,ISO2CodeID varchar (5)
,M49CodeID INT
,Country varchar(30)
,IntermediateRegionCode int
,IntermediateRegionName varchar (25)
,RegionCode int
,RegionName varchar (25)
constraint PK_Geograph_ISOCodeID primary key (ISOCodeID)
)

CREATE TABLE RemoteRatio (
RemoteID int
,WorkType varchar(25)
constraint PK_RemoteRatio_RemoteID primary key (RemoteID)
)

CREATE TABLE CompanyDimension (
CompanyDimID varchar(2)
,DimName varchar(10)
,EmployeeN varchar(15)
constraint PK_CompanyDimension_CompanyDimID primary key (CompanyDimID)
)

CREATE TABLE GeographCompany (
ISOCodeID varchar (5)
,ISO2CodeID varchar (5)
,M49CodeID INT
,Country varchar(30)
,IntermediateRegionCode int
,IntermediateRegionName varchar (25)
,RegionCode int
,RegionName varchar (25)
constraint PK_GeographCompany_ISOCodeID primary key (ISOCodeID)
)

CREATE TABLE SalariesIT (
 WorkYear date 
,ExperienceLevel varchar(5)
,EmploymentType varchar(5)
,JobTitle varchar(50)
,Salary money
,SalaryCurrency varchar(5)
,SalaryUSD money
,EmployeeResidence varchar(5)
,RemoteRatio int
,CompanyLocation varchar(5)
,CompanySize varchar(2)
,CONSTRAINT FK_SalariesIT_ExperienceLevel_ExperienceID foreign key (ExperienceLevel)
  references ExperienceLevel (ExperienceID)
,CONSTRAINT FK_SalariesIT_EmploymentType_EmploymentID foreign key (EmploymentType)
  references EmploymentType (EmploymentID)
,CONSTRAINT FK_SalariesIT_Currency_CurrencyID foreign key (SalaryCurrency)
  references Currency (CurrencyID)
,CONSTRAINT FK_SalariesIT_Geograph_ISOCodeID foreign key (EmployeeResidence)
  references Geograph (ISOCodeID)
,constraint FK_SalariesIT_RemoteRatio_RemoteID foreign key (RemoteRatio)
references RemoteRatio (RemoteID)
,CONSTRAINT FK_SalariesIT_CompanyDimension_CompanyDimID foreign key (CompanySize)
  references CompanyDimension (CompanyDimID)
)